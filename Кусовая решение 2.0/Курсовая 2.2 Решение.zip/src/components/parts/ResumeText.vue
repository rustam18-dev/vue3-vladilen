<template>
  <p>{{ $attrs.value }}</p>
</template>